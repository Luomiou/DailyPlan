%�������
function A=jiaocha(A,Pc,codelength)

for i=3:2:9
    p=(rem(fix(rand(1)*65535),1000))/1000;
    if(p<Pc)
        point=(rem(fix(rand(1)*65535),codelength-1))+1;
        A1=A(i,1:point);A2=A(i,point+1:10);
        B1=A(i+1,1:point);B2=A(i+1,point+1:10);
        A(i,:)=[B1 A2];A(i+1,:)=[A1 B2];
    end
end
end