%�������
function A=bianyi(A,Pm,codelength)

for i=2:10
    p=(rem(fix(rand(1)*65535),1000))/1000;
    if(p<Pm)
        point=(rem(fix(rand(1)*65535),codelength))+1;
        if(A(i,point)==0)
            A(i,point)=1;
        else
            A(i,point)=0;
        end
    end
end
end