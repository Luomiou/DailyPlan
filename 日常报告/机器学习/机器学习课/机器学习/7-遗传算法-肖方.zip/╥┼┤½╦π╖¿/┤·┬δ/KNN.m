function correct = KNN(B1)
data=xlsread('C:\Users\jhw\Desktop\�Ŵ��㷨\����\CORK_STOPPERS.XLS',2);
% A=xlsread('C:\Users\Administrator\Desktop\CORK_STOPPERS.xls',2);
train_data=data(:,B1(1,1)+2);
for l=2:10
    if(B1(l,1)~=0)
        train_data=[train_data data(:,B1(l,1)+2)];
    end
end
test_data=train_data;
res=zeros(3,3);

train_label=data(:,2);

k=knnclassify(test_data,train_data,train_label,3,'euclidean','random');
for j=0:2
    n1=0;
    n2=0;
    n3=0;
    for i=1:50
        if(k(50*j+i)==1)
            n1=n1+1;
        elseif(k(50*j+i)==2)
            n2=n2+1;
        elseif(k(50*j+i)==3)
            n3=n3+1;
        end
        res(j+1,1:3)=[n1 n2 n3];
    end
end
correct=(res(1,1)+res(2,2)+res(3,3))/150;
end