function SumOfAver = SumOfAverage(Data,a)

SumOfAver = 0;
for i = 1:10
    if a(i) ~= 0
       SumOfAver = SumOfAver + mean(Data(:,i))
    end
end