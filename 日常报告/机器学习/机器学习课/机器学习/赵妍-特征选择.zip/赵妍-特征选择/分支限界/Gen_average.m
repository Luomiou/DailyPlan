function Result = Gen( Result,Matrix,bound,Data,n,c)


NumOfFeature = size(Data,2);
NumOfLay = Matrix(1,2);
NumOfBrother = Matrix(1,3);
RankOfBrother = Matrix(1,4);
Have = Matrix(2,:);
Lost = Matrix(3,:);
Value = Matrix(1,5);
Temp = {};   


cutnum=0;
for iii=1:10
    if Lost(1,iii)==0
        cutnum=cutnum+1;
    end
end


%%
if Value < bound
    Matrix(1,1) = 1;
    Result{c,n} = Matrix;
    return 
else
    Matrix(1,1) = 1;
    Result{c,n} = Matrix;
    if NumOfLay==1
        NumOfSon = 4+1;
    else
        NumOfSon = NumOfBrother - RankOfBrother + 1;
    end
    for i= 1:cutnum     
        A = zeros(3,NumOfFeature);
        A(1,1:3) = [0,NumOfLay+1,NumOfSon];
        HL = find((Have - Lost)>0);
        x = HL(1,i);
        D = Have;
        E = zeros(1,NumOfFeature);
        D(1,x) = 0;
        E(1,x) = x;
        A(2:3,:)=[D;E];
        SumOfAver = SumOfAverage(Data,D)
        A(1,5) = SumOfAver;
        Temp{i,1} = A;
    end
    B = zeros(3,NumOfFeature); 
    for i =1:cutnum-1
        j = i + 1;
        while j<=cutnum
            if Temp{i,1}(1,5) > Temp{j,1}(1,5)
                B = Temp{i,1};
                Temp{i,1} = Temp{j,1};
                Temp{j,1} = B;
            end
            j = j+1;
        end
        Temp{i,1}(1,4) = i;
    end
    Temp{NumOfSon,1}(1,4) = NumOfSon;
    H = Lost;
    for i = 1:NumOfSon 
        u = find(Temp{i,:}(3,:)~=0);
        Temp{i,:}(3,:) = Temp{i,:}(3,:)+ H;
        H(1,u) = u;
    end
end
%%

N = size(Result,2);
if N==NumOfLay
    Result{1,NumOfLay+1} = zeros(3,NumOfFeature);
    for i=1:NumOfSon
        Result{i,NumOfLay+1} = Temp{i,1};
    end
else
    M = size(Result(:,NumOfLay+1),1);
    L = 0;
    for i =1:M
        if size(Result{i,NumOfLay+1},1)~=0
            L= L+1;
        end
    end
    for i=1:NumOfSon
        Result{i+L,NumOfLay+1} = Temp{i,1};
    end
end

end

